# Fixed CPU example splits

[简体中文](README.zh-CN.md)

`pairs.csv` contains the 18 ordered protein pairs and labels used by this directory's `splits.json`. Restore resources from the repository root using `python3 scripts/resource_packages.py extract`, then prepare matching features:

```bash
uv run deephvi prepare-features --resources-dir data --config configs/cpu_smoke_esm.yaml \
  --pairs data/splits/cpu_smoke/pairs.csv --out runs/fixed-features --device cpu
```

Pass `--splits data/splits/cpu_smoke` and `--bundle runs/fixed-features` to staged training commands. The protocol uses seed 42, an outer 80/20 split, and three validation folds within the training portion. `manifest.json` records input fingerprints, statistics, and protein overlap. This small subset checks execution and does not measure full-dataset performance. See the repository's `docs/usage.md` for training and evaluation commands.
