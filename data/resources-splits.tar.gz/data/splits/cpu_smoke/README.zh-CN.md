# 固定 CPU 示例划分

[English](README.md)

`pairs.csv` 包含本目录 `splits.json` 对应的 18 对有序蛋白样本及标签。在仓库根目录用 `python3 scripts/resource_packages.py extract` 恢复资源后，生成配套特征：

```bash
uv run deephvi prepare-features --resources-dir data --config configs/cpu_smoke_esm.yaml \
  --pairs data/splits/cpu_smoke/pairs.csv --out runs/fixed-features --device cpu
```

分阶段训练时使用 `--splits data/splits/cpu_smoke` 和 `--bundle runs/fixed-features`。协议采用 seed=42、外层 80/20 划分和训练部分三折验证。`manifest.json` 记录输入指纹、统计和蛋白重叠。该子集用于检查执行流程，不代表完整数据性能；训练与评估命令见仓库的 `docs/zh-CN/usage.md`。
